export interface ISelect {
  setSelect: (value: any) => void
  select: any
}