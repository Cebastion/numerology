export interface IRadio {
  setSelect: (value: any) => void
  setOpen: (value: any) => void
  select: any
}