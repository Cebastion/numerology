export interface ISendCode {
  code?: number
  email?: string
}
