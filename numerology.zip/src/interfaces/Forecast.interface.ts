export interface IValidForecast {
  Name?: boolean
  Date?: boolean
  Gender?: boolean
}