export interface IValidMatrix {
  Name?: boolean
  Date?: boolean
  Gender?: boolean
}

export interface IMatrix {
  Name: string
  Date: string
  Gender: string
}