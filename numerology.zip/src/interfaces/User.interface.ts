export interface IUser {
  calculates: [
    {
      birthday: string,
      calculator: string,
      gender: string,
      name: string,
      result: {}
    }
  ],
  created_at: string,
  name: string,
  plan: string
}