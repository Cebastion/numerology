export interface IToken {
  auth_token: string,
  result: boolean
}