export interface IPayTariff {
  link: string
  result: boolean
}

export interface IResultPayTariff {
  result: boolean
}