export interface IValidCompatibility {
  WomanName?: boolean
  ManName?: boolean
  WomanDate?: boolean
  ManDate?: boolean
}